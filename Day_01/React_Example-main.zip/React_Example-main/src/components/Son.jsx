import React from "react";

export default function Son({ text }) {
  return (
    <div>
      我是子層<p>{text}</p>
    </div>
  );
}
