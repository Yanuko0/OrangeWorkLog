import React from "react";

export default function Section() {
  let title = "";
  const text = "這是一個段落";
  title = "aa";
  return (
    <div>
      <h1>{title}</h1>
      <p>{text}</p>
    </div>
  );
}
